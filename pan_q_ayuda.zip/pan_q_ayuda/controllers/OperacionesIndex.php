<?php
    include("../partials/_header.html");

    include("../views/index.html");

    include("../partials/_footer.html");
?> 