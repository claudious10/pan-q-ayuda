<?php
    include("../partials/_header.html");

    include("../views/miembros.html");

    include("../partials/_footer.html");
?> 